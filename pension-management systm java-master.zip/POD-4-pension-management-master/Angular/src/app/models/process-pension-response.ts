export class ProcessPensionResponse {
    constructor(public processPensionStatusCode: number){ }
}
